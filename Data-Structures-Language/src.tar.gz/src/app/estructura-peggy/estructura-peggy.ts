import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Parser } from './parser/parser';

@Component({
  selector: 'app-estructura-peggy',
  imports: [FormsModule],
  templateUrl: './estructura-peggy.html',
  styleUrl: './estructura-peggy.css',
})
export class EstructuraPeggy {
  texto:string = "";
  private parser:Parser;

  constructor(parser:Parser){
    this.parser = parser;
    
  }

  parsear(){

    try{
      let nodo = this.parser.compilar(this.texto);
      alert("Es un binario y su valor decimal es:"+nodo.val)
    }catch(e:any){
      console.log(e);
      alert("No es Binario")
    }

  }
}
