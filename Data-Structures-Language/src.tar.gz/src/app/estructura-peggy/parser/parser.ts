import { Injectable } from '@angular/core';
import * as peggy from 'peggy';


@Injectable({
  providedIn: 'root',
})
export class Parser {

  // ! Viene de js (Le ponga null si viene '')
  private compilador!:peggy.Parser;

  constructor(){
    this.compileGrammar();
  }

  private compileGrammar(){

    const grammar = 
    `
        {
          //Aqui se escribe cualquier Codigo de JS 
          function potenciaDos(pot){
              let resultado = 1;
              for(let i = 1; i<= pot; i++){
                  resultado = 2*resultado;
              }
              return resultado;
          }
        }
        I = s:S{
                let nodo = {...s};
                return nodo;
            }
        S = b:B s:S{
                let nodo = {};
                nodo.val = potenciaDos(s.pot+1)*b.val + s.val;
                nodo.pot = s.pot + 1;
                return nodo;
            } 
            /b:B{
                let nodo = {...b};
                return nodo;
            }
        B = "0"{
                let nodo = {};
                nodo.val = 0;
                nodo.pot = 0;
                return nodo;
            }
            /"1"{
                let nodo = {};
                nodo.val = 1;
                nodo.pot = 0;
                return nodo;
            }
    `;
    this.compilador = peggy.generate(grammar);
  }

  compilar(texto:string):any{
    return this.compilador.parse(texto);
  }
  
}
